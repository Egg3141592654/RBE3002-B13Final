#! /usr/bin/env python

import rospy

#message types we may need
from std_msgs.msg import String
# from geometry_msgs.msg import Twist
# from geometry_msgs.msg import Quaternion
# from kobuki_msgs.msg import BumperEvent
# from sensor_msgs.msg import Imu
# from std_msgs.msg import Float64
# from nav_msgs.msg import Odometry

#Occupancy grid stuff we may use
from nav_msgs.msg import OccupancyGrid  #http://docs.ros.org/api/nav_msgs/html/msg/OccupancyGrid.html
from nav_msgs.msg import MapMetaData    #http://docs.ros.org/api/nav_msgs/html/msg/MapMetaData.html
from nav_msgs.msg import GridCells      #http://docs.ros.org/api/nav_msgs/html/msg/GridCells.html
from map_msgs.msg import OccupancyGridUpdate    #http://docs.ros.org/api/map_msgs/html/msg/OccupancyGridUpdate.html
from geometry_msgs.msg import Point             #http://docs.ros.org/api/geometry_msgs/html/msg/Point.html   

#usefull methods
from tf.transformations import euler_from_quaternion

#start and end goal
from move_base_msgs.msg import MoveBaseActionGoal
from geometry_msgs.msg import PoseWithCovarianceStamped

#paths
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
from geometry_msgs.msg import Pose

#usefull python
import math
import numpy
import random


print "LAB3 PYTHON SCRIPT STARTED..."

############################# GLOBALS ###################

#properties of the occupancyGrid we receive
G_OccupancyMap=OccupancyGrid()
G_GridCols=0;
G_GridRows=0;
G_TotalCells=0;
G_GridOriginX=0;
G_GridOriginY=0;
G_OccupancyMapResolution=0.05 #defualt resolution for occupancy maps in m/cell

#AStar things
G_Expanded=GridCells()
G_Frontier=GridCells()
G_Heuristic=[0.0]
G_HeuristicMultiplier=10.0


# curMap = {
#           "width":0,
#           "height":0,
#           "originX":0,
#           "originY":0,
#           "data":()
#           }

#GridCells overlay

# curVals = {   #initialize curVals (odometry)
#            "px":0,
#            "py":0,
#            "theta":0,
#            "vx":0,
#            "vy":0,
#            "vtheta":0
#            }

#start and goal as dicts in grid coordinates (480x512)
G_Start = {"px":0,"py":0,"theta":0}
G_Goal = {"px":0,"py":0,"theta":0}

#start and goal as points in world coordniates (meters)
# G_GoalPoint=Point()
# G_StartPoint=Point()
################################################ HELPERS #############################################

        
def printGlobalOccupancyMapInfo():
    print "Received Occupancy Map of size <" + str(G_GridCols) + "x" + str(G_GridRows) + "> Located at (" + str(G_GridOriginX)+","+str(G_GridOriginY)+")"
      
def resetGridCells():
    print "Resetting Grid"
    #update G_GridCells with info from this new OccupancyGrid       
    global G_GridCells
    global G_OccupancyMapResolution
    G_GridCells.cell_height=G_OccupancyMapResolution 
    G_GridCells.cell_width=G_OccupancyMapResolution 
    G_GridCells.header.frame_id="map"   
             
################################################ CALLBACK FUNIONS #############################################

def initialPoseCallback(PoseWithCovarianceStamped):
    print "INITIAL POSE CALLBACK"
    global G_Start
#     global G_StartPoint
    global G_OccupancyMapResolution 
    global G_GridOriginX
    global G_GridOriginY
#     G_StartPoint=PoseWithCovarianceStamped.pose.pose.position
    
    gridStartPoint=realtoGridCoordinates(PoseWithCovarianceStamped.pose.pose.position)
    G_Start["px"]=gridStartPoint.x
    G_Start["py"]=gridStartPoint.y
#     G_Start["px"] = (PoseWithCovarianceStamped.pose.pose.position.x-G_GridOriginX)/G_OccupancyMapResolution
#     G_Start["py"] = (PoseWithCovarianceStamped.pose.pose.position.y-G_GridOriginY)/G_OccupancyMapResolution
    
#     G_Start["px"] = PoseWithCovarianceStamped.pose.pose.position.x
#     G_Start["py"] = PoseWithCovarianceStamped.pose.pose.position.y
    quat = PoseWithCovarianceStamped.pose.pose.orientation
    q = [quat.x, quat.y, quat.z, quat.w]
    roll, pitch, yaw = euler_from_quaternion(q)
    G_Start["theta"] = math.degrees(yaw) + 180
    
    print "Received New Start: ("+str(PoseWithCovarianceStamped.pose.pose.position.x)+","+str(PoseWithCovarianceStamped.pose.pose.position.y)+","+str(PoseWithCovarianceStamped.pose.pose.position.z)+") which in Grid Coordinates is ("+ str(G_Start["px"])+","+str(G_Start["py"])+")"
    
    publishStartGoal()
    
    print "...done with initial pose callback"
       
def simpleGoalCallback(poseStampedGoal):
    print "SIMPLE GOAL CALLBACK"
    
    global G_Goal
#     global G_GoalPoint
    global G_OccupancyMapResolution 
    global G_GridOriginX
    global G_GridOriginY
#     G_GoalPoint=poseStampedGoal.pose.position
    
    gridGoalPoint=realtoGridCoordinates(poseStampedGoal.pose.position)
    G_Goal["px"]=gridGoalPoint.x
    G_Goal["py"]=gridGoalPoint.y
#     G_Goal["px"] = int((poseStampedGoal.pose.position.x-G_GridOriginX)/G_OccupancyMapResolution)
#     G_Goal["py"] = int((poseStampedGoal.pose.position.y-G_GridOriginY)/G_OccupancyMapResolution)
    print "Received New Goal: ("+str(poseStampedGoal.pose.position.x)+","+str(poseStampedGoal.pose.position.y)+","+str(poseStampedGoal.pose.position.z)+") which in Grid Coordinates is ("+ str(G_Goal["px"])+","+str(G_Goal["py"])+")"
    
    publishStartGoal()
    recalculateHeuristic()
    recalculateAStar()

    print "...done with simple goal callback"

def occupancyGridCallback(occupancyGrid):
    print "OCCUPANCY GRID CALLBACK"
    
    #import globals
    global G_OccupancyMap
    global G_GridCols
    global G_GridRows
    global G_GridOriginX
    global G_GridOriginY
    global G_MapHeightMeters
    global G_MapWidthMeters
    global G_TotalCells
    
    #fill globals
    G_OccupancyMap=occupancyGrid
    G_GridCols = G_OccupancyMap.info.width
    G_GridRows=G_OccupancyMap.info.height
    G_TotalCells=G_GridCols*G_GridRows
    G_GridOriginX=G_OccupancyMap.info.origin.position.x
    G_GridOriginY=G_OccupancyMap.info.origin.position.y
    
    #calculate derived variables
    G_MapWidthMeters=G_OccupancyMapResolution*G_GridCols
    G_MapHeightMeters=G_OccupancyMapResolution*G_GridRows 
        
    #print results to confirm
    printGlobalOccupancyMapInfo()
    
    resetGridCells()
    
#     print G_OccupancyMap
    print "\t...done receiving occupancy grid"
    
def mapMetaDataCallback(mapMetaData):
    printd("MAP META DATA")
    printd(mapMetaData)
    
def moveBaseLocalCostmapCallback(localCostMap):
    printd("LOCAL COST MAP")
    printd(localCostMap)
    
def moveBaseGlobalCostmapCallback(globalCostMap):
    printd("GLOBAL COST MAP")
    printd(globalCostMap)
    
def moveBaseLocalCostmapUpdateCallback(localCostMapUpdate):
    printd("LOCAL COST MAP UPDATE")
    printd(localCostMapUpdate)
    
def moveBaseGlobalCostmapUpdateCallback(globalCostMapUpdate):
    printd("GLOBAL COST MAP UPDATE")
    printd(globalCostMapUpdate)
       
################################################ PUBLISHERS #############################################
         
def publishStartGoal():
    global G_Start
    global G_Goal
    
    print "PUBLISHING START and GOAL where Goal is ("+str(G_Goal["px"])+","+str(G_Goal["py"])+") and start is ("+str(G_Start["px"])+","+str(G_Start["py"])+")"

#     global G_StartPoint
#     global G_GoalPoint
    
#     start=Point(G_StartPoint.x, G_StartPoint.y,100)
#     goal=Point(G_GoalPoint.x, G_GoalPoint.y,100)      
#     gridCoordinatesStartGoalpointList=[realtoGridCoordinates(start), realtoGridCoordinates(goal)]
    
    gridCoordinatesStartGoalpointList=[ Point(G_Start["px"],G_Start["py"],0),   Point(G_Goal["px"],G_Goal["py"],0)]
    publishGridPointListAsGridCells(gridCoordinatesStartGoalpointList,startGoalPublisher)
    
def publishRealWorldPointListAsGridCells(pointsInRealCoordinates, publisher):
#     print "Publishing list of points: "
#     print pointsInRealCoordinates
    
    global G_GridCols
    global G_GridRows
    global G_GridCells
    
    displayGridCells=G_GridCells
    
#     print "\twith resolution: "+str(G_OccupancyMapResolution)
    displayGridCells.cell_height=G_OccupancyMapResolution 
    displayGridCells.cell_width=G_OccupancyMapResolution 
    displayGridCells.header.frame_id="map"
    
    displayGridCells.cells=pointsInRealCoordinates
    
#     print "\tGridCells:"
#     print displayGridCells
    
    publisher.publish(displayGridCells)
#     print "...Done Publishing Point List"  

def publishGridPointListAsGridCells(pointsInGridCoordinates, publisher):
    pointsInRealCoordinates=[gridToRealWorldCoordinates(gridPoint) for gridPoint in pointsInGridCoordinates]
    publishRealWorldPointListAsGridCells(pointsInRealCoordinates, publisher)
              
def publishFrontier(points):
    print "Publishing Frontier"
    publishGridPointListAsGridCells(points, frontierPublisher)
    
def publishExpanded(points):
    print "Publishing Expanded"
    publishGridPointListAsGridCells(points, expandedPublisher)
    
def publishHeuristic():
    print "Publishing Heuristic"  
    global G_OccupancyMap
    global G_Heuristic
    global G_GridCols
    global G_GridRows
    global G_TotalCells
    global G_Goal   
    global G_HeuristicMultiplier
         
    #make another heurostic which is normalized s that values are within [0,100]
    displayHeuristic=G_OccupancyMap
    maxValue=(100.0)/(G_HeuristicMultiplier*(G_GridCols+G_GridRows))#normalize everything by 100
    print "\tNormalizing cells by "+ str(G_GridCols) + "+" + str(G_GridRows) +" = " + str(maxValue)
    lstDisplayHeuristic=[]#list(displayHeuristic.data) #make a list from the grid's tuple of cells
    totCells=G_TotalCells
    for index in range(totCells):#loop through all grid cells
        cell=int(G_Heuristic[index]*maxValue)#set to the normalized value of the display heuristic
        
        #check if its the goal - make the goal 100
        col=getColOfIndex(index)
        row=getRowOfIndex(index)
        if ((col == G_Goal["px"] and  row==G_Goal["py"]) or (col == G_Start["px"] and row == G_Start["py"])):
            print "\t\tFound Start or Goal at ("+str(col)+","+str(row)+")"
            cell=100
        
        #lstDisplayHeuristic[index]=cell
        lstDisplayHeuristic.append(cell)    
#         print "\tnormalizing (index "+str(index)+"): " + str(G_Heuristic[index]) + " by " + str(maxValue) + " to get " + str(lstDisplayHeuristic[index])
        
    displayHeuristic.data = tuple(lstDisplayHeuristic)#turn it back into a tuble
        
    displayHeuristic.header.frame_id="map"
#     print displayHeuristic

    heuristicPublisher.publish(displayHeuristic)
    print "\t...done publishing heuristic"
  
################################################ MAIN ALGORITHMS #############################################

def getIndexOfGridPosition(x, y):
    global G_GridCols
    return y*G_GridCols+x

def getColOfIndex(index):
    global G_GridCols
    return index%G_GridCols 
#         print "\tcol of cell " + str(index) + " of cols("+str(G_GridCols)+") is " + str(index%G_GridCols)

def getRowOfIndex(index):
    global G_GridRows
#         print "\trow of cell " + str(index) + " of rows("+str(G_GridRows)+") is " + str(index%G_GridRows)
    return math.floor(index/G_GridRows)

def getIndexOfGridPoint(point):
    global G_GridCols
    return getIndexOfGridPosition(point.x, point.y)
#recalculates the heuristic based on a new start and goal   

def recalculateHeuristic():
    print "Recalculating Heuristic..."
    global G_Heuristic
    global G_GridCols
    global G_GridRows
    global G_Goal
    global G_TotalCells
    global G_HeuristicMultiplier
    print "Calculating Heuristic for " + str(G_GridCols) + "x" + str(G_GridRows) + " grid for goal (" + str(G_Goal["px"]) + "," + str(G_Goal["py"]) + ")" 
    
    #get distance to the goal (in grid coordinates)
    def getDistancefromGoal(index):
        col=getColOfIndex(index)
        row=getRowOfIndex(index)
#         print "Goal Coordinate According to Heuristic"
#         print G_Goal["px"]
#         print G_Goal["py"]
#         
        dist=math.sqrt(math.pow( (G_Goal["px"]-col), 2 ) + math.pow( (G_Goal["py"]-row), 2) )
#         print "Distance Between index " + str(index) + " and Goal at (" + str(G_Goal["px"]) +"," + str(G_Goal["py"]) +") is "+str(dist) 
        return dist
    
    #calculate new heuristic based on occupancy grid size and goal position
    G_Heuristic=[]   #reset occupancy grid list
    totCells=G_TotalCells
    for index in range(totCells):#loop through all grid cells
        h=G_HeuristicMultiplier*getDistancefromGoal(index)
        G_Heuristic.append(h)
#         print "distance of goal ("+str(G_Goal["px"])+","+str(G_Goal["py"])+") from cell " + str(index) + " is " + str(h) + " is " + str(G_Heuristic[index])
    print "...done calculating heuristic:"
#     print G_Heuristic
#     print "\n"*20
   
    #show the new heuristic for visualization
    publishHeuristic()
    
#recalculates A* and publishes the new overlay       
def getHeuristicAtPosition(x, y):
    global G_Heuristic  
    return G_Heuristic[getIndexOfGridPosition(x,y)]
def getHeuristicAtPoint(point):
    global G_Heuristic 
    return G_Heuristic[getIndexOfGridPoint(point)]
#     return getHeuristic(p.x, p.y)    
   
#     makeRandomGridCells()
#     publishCurrentGridCells()
    
#calculate one iteration of AStar    

#puts the given list of points (in world coordinates) as the cells in a GridCells and publishes it to the given topic
    
def gridToRealWorldCoordinates(gridPoint):
    global G_OccupancyMapResolution
    global G_GridOriginX
    global G_GridOriginY
    #add point 5 0.5 to center the point on the grid cell
    x=(gridPoint.x+0.5)*G_OccupancyMapResolution + G_GridOriginX
    y=(gridPoint.y+0.5)*G_OccupancyMapResolution + G_GridOriginY
    return Point(x,y,gridPoint.z)

def realtoGridCoordinates(realPoint):
    global G_OccupancyMapResolution
    global G_GridOriginX
    global G_GridOriginY
    x=int((realPoint.x-G_GridOriginX)/G_OccupancyMapResolution)
    y=int((realPoint.y-G_GridOriginY)/G_OccupancyMapResolution)
    return Point(x,y,realPoint.z)

def recalculateAStarFake():
    print "dummy A Star"
    
class Node:
#         x=0
#         y=0
#         gscore=0
#         fscore=0
        
#         def __init__(self, X, Y, G, H=None):
#             self.x=X
#             self.y=Y
#             self.gscore=G
#             self.hscore=H
            
    
    def __init__(self, X, Y, G):
        self.x=X
        self.y=Y
        self.gscore=G
        self.fscore=G+getHeuristicAtPosition(X, Y)
    
    def toString(self):
        return "(X"+str(self.x)+", Y"+str(self.y)+", G"+str(self.gscore)+", F" +str(self.fscore)+")"
    
def nodeListToPointList(nodes):
    return [Point(node.x, node.y, 0) for node in nodes]
     
def recalculateAStar():    
    print "AStar..."
     #import globals
    global G_OccupancyMap
    global G_GridCols
    global G_GridRows
    global G_GridOriginX
    global G_GridOriginY  
    global G_OccupancyMapResolution
    global G_MapHeightMeters
    global G_MapWidthMeters
    global G_GridCells
    global G_TotalCells
    global G_Start
    global G_Goal
    global closedset    #explored
    global openset      #frontier
    
    #    g(x) = past path cost - known distance to node g(x')=g(x)+d(x,x')
    #    h(x) = future path cost estimate - heuristic
    #    f(x) = prioritizing cost function - f(x) = g(x) + h(x)
    
   
    def printNodeList(nodes):
        print "\t\t\t["+str(len(nodes))+"]"
#         for node in nodes:
#             print node.toString()
    
      
    #return the point in the list with the lowest z value (score)
    def getLowestFScore(nodes):
        return sorted(nodes, key=lambda point: point.fscore)[0]
    
    def getHeuristicAtNode(node):
        return getHeuristicAtPosition(node.x, node.y)
         
    def samePlace(nodeA, nodeB):
        if (nodeA.x==nodeB.x and nodeA.y==nodeB.y):
            return True
     
    def isObstacle(node):
        global G_OccupancyMap
        
        print "\t\tChecking if " + node.toString() + " is occupied..."
        index = getIndexOfGridPosition(node.x, node.y)
        print "\t\tIndex is: " + str(index)
        occupancyValue=G_OccupancyMap.data[index]
        print "\t\tOccupancy value is: " + str(occupancyValue)
        occupied=(occupancyValue > 50 or occupancyValue==-1)
        print "\t\tOccupied is " + str(occupied)
        return occupied
 
    #gets the neighbors of the given point
    def getNeighborsOf(node):
        global G_GridRows
        global G_GridCols
        
#         print "\tFinding Neighbors of node "+ node.toString()
        
        topY=node.y+1
        bottomY=node.y-1
        leftX=node.x-1
        rightX=node.x+1
        
        neighbors=[]
        if (bottomY>=0):#if the bottom is not below the grid bounds
            neighbors.append(Node(node.x, bottomY, node.fscore))      #add cell directly above
            
            #diagonals down
            if (leftX>=0):
                neighbors.append(Node(leftX, topY, node.fscore))    #add cell above to the left
            if (rightX<G_GridCols):
                neighbors.append(Node(rightX, topY, node.fscore))   #add cell above to the right
        if (topY<G_GridRows):#if the top is not above the grid bounds
            neighbors.append(Node(node.x, topY, node.fscore))      #add cell below
            
            #diagonals uo
            if (leftX>=0):
                neighbors.append(Node(leftX, bottomY, node.fscore)) #add cell below to the left
            if (rightX<G_GridCols):
                neighbors.append(Node(rightX, bottomY, node.fscore))#add cell below to the right
        if (leftX>=0):  #if left is not to out of the grid to the left
            neighbors.append(Node(leftX, node.y, node.fscore))     #add cell to the left
        if (rightX<G_GridCols): #if right is not out of the grid to the right
            neighbors.append(Node(rightX, node.y, node.fscore))    #add cell to the right
        
#         print "\tFound "+str(len(neighbors)) +" neighbors"
        
        #remove obstacles    
        neighbors=[unoccupiedNeighbor for unoccupiedNeighbor in neighbors if (not isObstacle(unoccupiedNeighbor))]
#         totNeighbors=len(neighbors)
#         print "Looping through "+ str(totNeighbors) +" neighbors..."
#         for index in range(totNeighbors) : 
#             print "\tindex: "+str(index)
#             obstacleNeigbor=neighbors[index]
#             print "\ttesting for obstacle at "+obstacleNeigbor.toString()
#             if isObstacle(obstacleNeigbor):
#                 neighbors.__delitem__(index)  

#         print "\tReturning "+str(len(neighbors))+ " neighbors"
                 
        return neighbors
    
    
    #MAIN A STAR ALGORITHM
    
    def getItemAtSamePositionIn(nodes, positionNode):
        print "\t\tSearching for "+positionNode.toString()+"through nodes "
        printNodeList(nodes)
        for node in nodes:
            if node.x==positionNode.x and node.y==positionNode.y:
#                 print "\t\t\tFound node!"
                return node
        print "\t\tFound no such node"
        return None
    
    
    def reconstruct_path(parentList):
        print "Reconstructing Path..."
        #TODO
        return None
                       
    def getPathUsingAStar():
        print "\n\n\n\n\tcalculating A Star..."
         #work in grid coordinates
        
        print "\tStart Location: ("+str(G_Start["px"])+","+str(G_Start["py"])+")"
        print "\tGoal Location: ("+str(G_Goal["px"])+","+str(G_Goal["py"])+")"
        
        startHeuristic = getHeuristicAtPosition(G_Start["px"],G_Start["py"])
        startX = G_Start["px"]
        startY = G_Start["py"]
        goalX = G_Goal["px"]
        goalY = G_Goal["py"]
         
        start = Node(startX, startY,  0)
        goal = Node(goalX,  goalY,   0)                             #goal has no cost
        
        
                
        #print "Start Node: " + start.toString() + "\t Goal Node: " + goal.toString()
            
        #lists (stacks) of things for A Star, all in grid coordinates
        closedset = []
        openset = [start]
        parents = []
        #current=start
        
        while openset:  #while the openset is not empty (there is stuff left to explore on the frontier)
            print "\tCurrent open set is "
            printNodeList(openset)
            
            current=getLowestFScore(openset) #the current node we're exploring is the one on the frontier with the lowest score
#             print current.x
#             print current.y
            
            print "\tcurrently exploring node: " + current.toString()
            
            if samePlace(current,goal):   #if the current node is the goal
                print "Found Goal!"
                return reconstruct_path(parents)#reconstruct the path from the parent nodes list
            
            #current node is not the goal
            else:
                print "\tOld open set: "
                printNodeList(openset)
                print "\tOld closed set: "
                printNodeList(closedset)
                
                openset.remove(current)     #pop the currently being explored node from the frontier
                closedset.append(current)   #its being explored, so it will have been explored
                
                print "\tNew open set: "
                printNodeList(openset)
                print "\tNew closed set: "
                printNodeList(closedset)
 
                neighbors=getNeighborsOf(current)   #get the valid neighbor nodes
                print "\tNeighbors of node are: "
                printNodeList(neighbors)
                    
                for neighbor in neighbors:          #loop through neighbors
                    print "\tExpanding neighbor " + neighbor.toString()
                    
                    #for each neighbor we're considering, calculate what its g score would be
                    tentative_g_score = current.gscore + 1.0   #g'=g+cost(g->g') gscore of neighbor = gscor of current node + cost of moving to neighbor
                    tentative_f_score = tentative_g_score + getHeuristicAtNode(neighbor)  #f=g+h
                    
                    print "\t\tTentative G Score: "+ str(tentative_g_score)
                    print "\t\tTentative F Score: "+ str(tentative_f_score)
                    
                    #check if we've already been there through a shorter path
                    sameCellInClosedSet=getItemAtSamePositionIn(closedset,neighbor)    #try to find this grid in the closed set
                    if ((sameCellInClosedSet is not None) and tentative_f_score >= sameCellInClosedSet.fscore):   #if this point is already on the closed set and has a lower score there than we just calculated here
                        print "\tThis cell is either unexplored or already found but with a lower f score - moving on..."
                        continue   #then a shorter path to this neighbor has alredy been found - skip it
                    
                    #if this cell is no on the open set, or it is but has a higher fscore
                    sameCellInOpenSet=getItemAtSamePositionIn(openset,neighbor)   #try to find this grid cell in the open set
                    if ((sameCellInOpenSet is None) or (tentative_f_score < sameCellInOpenSet.fscore)):
                        print "\tThis cell is either not found on the open set or is on the open set with a higher f score"
#                         parents[neighbor] = current
                        neighbor.fscore=tentative_f_score
                        neighbor.gscore=tentative_g_score
                        if (sameCellInOpenSet is None):  #if the open set does not already contain the neighbor
                            print "\tAdding cell to open set"
                            openset.append(neighbor)            #add the neighbor
                        else:
                            print "\tReplacing cell "+sameCellInOpenSet.toString()+"in open set"
                            sameCellInOpenSet=neighbor
#                             openset.remove(sameCellInOpenSet)   #remove whatever was there
#                             openset.append(neighbor)            #add the new neighbor
                    else:
                        print "Node already on open set and has a larger f value - not doing anything"
            publishFrontier(nodeListToPointList(openset))
            publishExpanded(nodeListToPointList(closedset))
        return None
    
    G_CurrentPath=getPathUsingAStar()
      
    
################################################ TESTING RANDOMNESS #############################################    
G_GridCells =  GridCells()
def publishCurrentGridCells():
    print "Publishing GridCells"
    global G_GridCells
    gridCellsPublisher.publish(G_GridCells)
    
#Clears all grid cells and make a bunch of random ones         
def makeRandomGridCells():
    print "Making Random GridCells"
    #import globals
    global G_OccupancyMap
    global G_GridCols
    global G_GridRows
    global G_GridOriginX
    global G_GridOriginY  
    global G_OccupancyMapResolution
    global G_MapHeightMeters
    global G_MapWidthMeters
    global G_GridCells 
    #make some new grid cells
    
    resetGridCells()
    
    totalPoints=100
    for x in range(0, 100):
        randomPoint=Point()
        randomPoint.x=random.random()*G_MapWidthMeters
        randomPoint.y=random.random()*G_MapHeightMeters
        randomPoint.z=random.randrange(100)
        
        G_GridCells.cells.append(randomPoint);         
def publishRandomPath():
    #import globals
    global G_OccupancyMap
    global G_GridCols
    global G_GridRows
    global G_GridOriginX
    global G_GridOriginY  
    global G_OccupancyMapResolution
    global G_MapHeightMeters
    global G_MapWidthMeters

    #generate a random path thing
    path = Path()
    totalPoints=100
    for x in range(0, 100):
     
        poseStamped=PoseStamped()
     
        #randomize the position    
        poseStamped.pose.position.x=random.random()*G_MapWidthMeters
        poseStamped.pose.position.y=random.random()*G_MapHeightMeters
        poseStamped.pose.position.z=random.randrange(100)
          
        path.poses.append(poseStamped)
     
    #publish!
    pathPublisher.publish(path)
    print "Publishing path..."
    
################################################ MAIN PROGRAM ################################################    
def lab3():
    rospy.sleep(0.5)    #wait for first map to come in before doing anything

#     makeRandomGridCells()
#     publishCurrentGridCells()

    #LOOP FOREVER [or rospy.spin()]
    while not rospy.is_shutdown():
        rospy.spin()  
    
################################################ MAIN ################################################
# MAIN
if __name__ == '__main__':

    ############### GLOBALS ###############
#     G_OccupancyMap = OccupancyGrid()

    # register our node with roscore under this name
    rospy.init_node('lab3')  
    
    ############### publishers
    rospy.loginfo("MAKING PUBLISHERS")
    occupanceyGridPublisher=rospy.Publisher('lab2_heuristic', OccupancyGrid)
    gridCellsPublisher=rospy.Publisher('lab2_gridcell', GridCells)#publishes general grid cells for testing
    
    #A* stuff publishers
    heuristicPublisher=rospy.Publisher('lab2_heuristic',OccupancyGrid)
    expandedPublisher=rospy.Publisher('lab2_expanded', GridCells)
    frontierPublisher=rospy.Publisher('lab2_frontier', GridCells)
    startGoalPublisher=rospy.Publisher('lab2_StartGoal',GridCells)
#     pathPublisher = rospy.Publisher('lab2_path', Path)
    
    ############### SUBSCRIBERS
    rospy.loginfo("SUBSCRIBING TO TOPICS")
    
    #from map server
    rospy.Subscriber("map", OccupancyGrid, occupancyGridCallback)      #subscribe to OccupancyGrids posted on the map topic
#     rospy.Subscriber("map_metadata", MapMetaData, mapMetaDataCallback) #subscribe to MapMetaData posted on the 
    rospy.Subscriber("/initialpose", PoseWithCovarianceStamped, initialPoseCallback)
    rospy.Subscriber("/move_base_simple/goal",PoseStamped,simpleGoalCallback)
    
    
    #from move_base local
#     rospy.Subscriber("/move_base/local_costmap/costmap", OccupancyGrid, moveBaseLocalCostmapCallback)
#     rospy.Subscriber("/move_base/local_costmap/costmap_updates", OccupancyGridUpdate, moveBaseLocalCostmapUpdateCallback)
    
    #from move_base global
#     rospy.Subscriber("/move_base/global_costmap/costmap", OccupancyGrid, moveBaseLocalCostmapCallback)
#     rospy.Subscriber("/move_base/global_costmap/costmap_updates", OccupancyGridUpdate, moveBaseGlobalCostmapUpdateCallback)
    
    #MAIN PROGRAM
    try:
        lab3()  
    except rospy.ROSInterruptException: #main program loops so check it for exceptions while its waiting inbetween loops
        pass